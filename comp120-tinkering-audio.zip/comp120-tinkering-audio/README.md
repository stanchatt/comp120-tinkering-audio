# <p align="center">comp-120-tinkering-audio</p>
*<p align="center">by Matthew Taylor and Stanley Chatt 

## Contract Number 3 Music Generation
For our assignment we need to create a program that will generate a music track for a developer in the industry. 
The choice of genre is irrelevent as long as the program functions correctly.
### Stretch Goals
Creating a menu that lets the user change the music track that is playing.
https://github.com/StarTrails/comp120-tinkering-audio
